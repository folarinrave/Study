//
//  NewScreen.swift
//  segueProject
//
//  Created by Daniel Brannon on 10/12/21.
//

import UIKit
class NewScreen: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newScreenProperty.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel!.text = newScreenProperty[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var tableViewNewScreen: UITableView!
}
var newScreenProperty: [String?] = []
