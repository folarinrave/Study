//
//  ViewController.swift
//  segueProject
//
//  Created by Daniel Brannon on 10/12/21.
//

import UIKit

class ViewController: UIViewController {
    var stringToPassOn: String? = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        textfield.delegate = self
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var textfield: UITextField!
    @IBAction func MyFirstTextField(_ sender: UITextField) {
    }
    
    
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        stringToPassOn = textField.text
        return true
    }
}
